radius = float(input("Enter the radius: "))
area = 3.14159 * radius * radius
print("Area of the circle:", area)
